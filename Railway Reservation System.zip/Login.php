<?php
      $username=$_POST['username'];
      $pass=$_POST['pass'];
      $con=mysqli_connect("fdb21.awardspace.net","3401073_railway","shub7062");
      if($con)
      {
           $db=mysqli_select_db($con,"3401073_railway");
           if(!$db)
           {
                exit("Error In Database Selection");
           }
      }
      else
      {
            exit("Connection Not Established");
      }
      $q="select * from user1 where userid='$username' and password='$pass'";
      $a=mysqli_query($con,$q);
      if(mysqli_num_rows($a)>0)
      {
              header("Location:options.php?user=$username");
      }
      else
      {
              echo "Does not match";
      }
?>