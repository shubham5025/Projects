<?php
      session_start();
      $username=$_POST['username'];
      $pass=$_POST['pass'];
      $error="";
    if(isset($_POST['submit']))
    {
      $con=mysqli_connect("fdb21.awardspace.net","3401073_railway","shub7062");
      if($con)
      {
           $db=mysqli_select_db($con,"3401073_railway");
           if(!$db)
           {
                exit("Error In Database Selection");
           }
      }
      else
      {
            exit("Connection Not Established");
      }
      $q="select * from user1 where userid='$username' and password='$pass'";
      $a=mysqli_query($con,$q);
      if(mysqli_num_rows($a)>0)
      {
              $_SESSION['username']=$username;
              header("Location:options.php");
      }
      else
      {
              $error="Invalid Username or Password";
      }
    }
?>
<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1.0" charset="UTF-8">
<head>
    <link rel="stylesheet" type="text/css" href="homes.css">
    <title>
        Railway reservation
    </title>
</head>
<body>
<div class="page">
    <h1>Online Rail Reservation System</h1>
    <form action="home.php" class="box" method="POST"> 
        <h2>Login</h2>
        <p class="error"><?php echo " <font color='red'>$error</font>"; ?></p>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="pass" placeholder="Password" required>
        <p><input type="submit" value="Submit" name="submit"></p>
        <p>New Here?<a href="register1.php">Sign Up</a></p>
    </form>
    <div id="link" class="box">
        <h3>Popular Links</h3>
        <p><a href="home.php">Login</a></p>
        <p><a href="register1.php">Register here!!</a></p>
        <p><a href="">Contact Us</a></p>
    </div>
</div>
</body>
</html>