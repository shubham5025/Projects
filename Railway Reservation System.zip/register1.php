<?php
        $f_name = $_POST['fname'];
        $l_name = $_POST['lname'];
        $email =  $_POST['email'];
        $DOB =    $_POST['dob'];
        $gender = $_POST['gender'];
        $userid = $_POST['userid'];
        $mob_no = $_POST['phone'];
        $aadhar = $_POST['aadhar'];
        $address =$_POST['address'];
        $city =   $_POST['city'];
        $state =  $_POST['state'];
        $password=$_POST['pass'];
        $cpass =  $_POST['cpass'];
        $error="";
        $success="";
      if(isset($_POST['submit']))
      {
        if($password!=$cpass)
        {
               $error="Password and Confirm Password must be Same";
        }
        else{
        
        $con=mysqli_connect("fdb21.awardspace.net","3401073_railway","shub7062") or die("Connection Not established");
        if($con)
        {
           $db=mysqli_select_db($con,"3401073_railway");
           if(!$db)
           {
                exit("Error In Database Selection");
           }
        }
        $q="insert into user1(userid,F_name,L_name,Email,DOB,Gender,Mob_no,Aadhar,Address,City,State,password) values('$userid','$f_name','$l_name','$email','$DOB','$gender','$mob_no','$aadhar','$address','$city','$state','$password')";
        $a=mysqli_query($con,$q);
        if($a)
        {
                $success="Registered Succcessfully,Try Login Now";
        }
        else
        {
                    $error="Username already taken";
        }
        
        }
     }
?>
<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1.0" charset="UTF-8">
<head>
    <link rel="stylesheet" type="text/css" href="homes.css">
    <title>
        Railway reservation
    </title>
</head>
<body>
<div class="page">
    <h1>Online Rail Reservation System</h1>
    <div id="login" class="box"> 
    <form action="register1.php" method="POST">
        <span id="log"><h2>Registration</h2></span>
        <p class="error"><?php echo " <font color='red'>$error</font>"; ?></p>
        <p class="success"><?php echo "<font color='#1abc9c'><b>$success</b></font>"; ?></p>
        <p>First Name:<input type="text" name="fname" placeholder="First Name"  required></p>
        <p>Last Name:<input type="text" name="lname" placeholder="Last Name"  required></p>
        <p>Email:<input type="text" name="email" placeholder="E-mail" required></p>
        <p>Date of Birth:<input type="date" name="dob" placeholder="Date of Birth" min=1920-05-08 max=2002-05-08 required></p>
        <p>Gender: <select name="gender" >
            <option value="">Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="other">Other</option>
        </select></p>
        <p>Username:<input type="text" name="userid" placeholder="Username" maxlength="12" required></p> 
        <p>Mobile Number:<input type="tel" name="phone" placeholder="Mobile No" pattern="[0-9]{10}" required></p>
        <p>Aadhar No.:<input type="text" name="aadhar" placeholder="Aadhar No." pattern="[0-9]{12}" required></p>
        <p>Address:<input type="text" name="address" placeholder="Address" required></p>
        <p>City:<input type="text" name="city" placeholder="City" required></p>
        <p>State:<input type="text" name="state" placeholder="State" required></p>
        <p>Password:<input type="password" name="pass" placeholder="Password" min="6" max="35" title="Password Containing at least 6 character"required></p>
        <p>Confirm Password:<input type="password" name="cpass" min="6" max="35" placeholder="Confirm Password" title="Password same as above"required></p>
        <p><input type="submit" value="register" name="submit"></p>
       </form>
    </div>
    <div id="link" class="box">
        <h3>Popular Links</h3>
        <p><a href="home.php">Login</a></p>
        <p><a href="register1.php">Register here!!</a></p>
        <p><a href="">Contact Us</a></p>
    </div>
</div>
</body>
</html>