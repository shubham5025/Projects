<?php
        session_start();
        if(!isset($_SESSION['username']))
        {
                header("Location:home.php");
        }
?>
<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1.0" charset="UTF-8">
<head>
    <link rel="stylesheet" type="text/css" href="res.css">
    <title>
        Railway reservation
    </title>
</head>
<body>
<div class="page">
    <h1>Online Rail Reservation System</h1>
    <div class="box" id="acc" style="width: 300px;">
        <a href="account.php">My Account</a>
        <a href="options.php">Bookings</a>
    </div>
    <div class="box" id="option" align="center" >
    <form action="" method="POST" align="center">
        Source: <select name="from" >
            <option value=""></option>
            <option value="delhi">New Delhi</option>
            <option value="mumbai">Mumbai</option>
            <option value="Bhopal">Bhopal</option>
            <option value="gwalior">Gwalior</option>
            <option value="chandigarh">Chandigarh</option>
        </select>
        <br>Destination: <select name="to" >
            <option value=""></option>
            <option value="delhi">New Delhi</option>
            <option value="mumbai">Mumbai</option>
            <option value="Bhopal">Bhopal</option>
            <option value="gwalior">Gwalior</option>
            <option value="chandigarh">Chandigarh</option>
        </select>
        <input type="submit" name="search" value="search">
    </form>
    </div>
    <div id="link" class="box">
        <h3>Popular Links</h3>
        <p><a href="logout.php">Logout</a></p>
        <p><a href="">Contact Us</a></p>
    </div>
</div>
</body>
</html>