<?php
        session_start();
        if(!isset($_SESSION['username']))
        {
                header("Location:home.php");
        }
?>
<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1.0" charset="UTF-8">
<head>
    <link rel="stylesheet" type="text/css" href="homes.css">
    <title>
        Railway reservation
    </title>
</head>
<body>
<div class="page">
    <h1>Online Rail Reservation System</h1>
   
    <div class="box" id="option">
        <?php
                  $username=$_SESSION['username'];
                  $con=mysqli_connect("fdb21.awardspace.net","3401073_railway","shub7062") or die("Connection Not established");
                  if($con)
                  {
                         $db=mysqli_select_db($con,"3401073_railway") or die("Error In Database Selection");
                  }
                  $q="select * from user1 where userid='$username'";
                  $q1="SHOW FIELDS FROM user1";
                  $r1=mysqli_query($con,$q);      
                  $r=mysqli_query($con,$q1);
                  if($r)
                  {
                         $a1=mysqli_fetch_array($r1);
                         echo "<table>";
                         $i=0;
                          while($a=mysqli_fetch_array($r))
                          {
                               echo "<tr><td><font color='blue'>$a[0]:</font></td>";
                               echo "<td><font color='#1abc9c'>$a1[$i]</font></td></tr>";
                               $i=$i+1;
                          }
                          echo "</table>";
                                  
                  }
        ?>
    </div>
    
    <div id="link" class="box">
        <h3>Popular Links</h3>
        <p><a href="logout.php">Logout</a></p>
        <p><a href="">Contact Us</a></p>
    </div>
     <div class="box" id="acc">
            <a href='options.php'>Reservation</a>;
     </div>
</div>
</body>
</html>